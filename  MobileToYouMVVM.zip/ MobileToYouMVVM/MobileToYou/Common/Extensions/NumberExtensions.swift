//
//  NumberExtensions.swift
//  MobileToYou
//
//  Created by jplima on 28/11/22.
//

import Foundation

extension Int {
    func toString() -> String? {
        return "\(self)"
    }
}

extension Double {
    func toString() -> String? {
        return "\(self)"
    }
}
