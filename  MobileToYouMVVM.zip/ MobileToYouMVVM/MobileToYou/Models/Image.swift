//
//  Image.swift
//  MobileToYou
//
//  Created by jplima on 28/11/22.
//

import Foundation

// MARK: - Image
struct Image: Codable {
    let medium, original: String
}
