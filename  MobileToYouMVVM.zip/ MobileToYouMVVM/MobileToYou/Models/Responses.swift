//
//  Responses.swift
//  MobileToYou
//
//  Created by jplima on 28/11/22.
//

import Foundation

typealias EpisodeResponse = [Episode]
